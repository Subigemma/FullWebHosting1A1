GSI_MAX_ATTR = 20
GSIADD_VERSION = "2.0"
GSIADD_DATE = "Nov 2016"
IsRolOpen=false
StaticPopupDialogs ["GSIADD_ALERT"] = 
{
	text = "Toque de atencion",
	button1 = "OK" ,
	button2 = "Cancelar" ,
	hideOnEscape = true,
	OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("TOP")
	end,
	OnAccept = function (self, data, data2)
		local TxtEmote = self.editBox:GetText()
        SendAddonMessage("GSIADD", 
	    "SHALRT:" .. UnitName("player") ..":" 
	           .. UnitName("target") .. ":"
			   .. "3:4:5:"
               .. TxtEmote, "WHISPER", UnitName("target") )	
	end,	
	hasEditBox = true	
}

function GSILoadVars ()
   if GSIAddConf ["GSI_MAX_ATTR"] == nil then
      GSI_MAX_ATTR = 20
   else
      GSI_MAX_ATTR = GSIAddConf ["GSI_MAX_ATTR"]
   end
   if GSIAddConf == nil then
      GSIAddConf = {
	     ["Titulo"] = "",
	     ["Nombre"] = UnitName("Player"),
		 ["Apellidos"] = "",
		 ["Clase"] = UnitClass("Player"),
		 ["Raza"] = UnitRace("Player"),
		 ["Edad"] = "",
		 ["Altura"] = "",
		 ["Rollo"] = "",
		 ["Fuerza"] = 0,
		 ["Intelecto"] = 0,
		 ["Agilidad"] = 0,
		 ["Carisma"] = 0,
		 ["Resistencia"] = 0,
		 ["PuntosAttr"] = 20,
		 ["AttrInv"] = 0,
		 }
   end
   if KChars == nil then
      KChars = { ["New"] = "isnew" }
   end	  
   GSIAdd_Saved_ChatFrameEvent = nil
end

