--
-- Popup Dialogs
--
function GSIAddAlert ( Sender, MSG )
   message( Sender .. " te dice:\n" .. MSG)
end
function GSIShowRolGUID ()
   local AceGUI = LibStub("AceGUI-3.0")
   if GSIAddConf["Dmin"] == nil then
      GSIAddConf["Dmin"] = 1
   end
   if GSIAddConf["Dmax"] == nil then
      GSIAddConf["Dmax"] = 100
   end
   if GSIAddConf["RolNotes"] == nil then
      GSIAddConf["RolNotes"] = ""
   end
   local ABText = AceGUI:Create("Frame")
      ABText:SetCallback("OnClose",function(widget) 
	                                 IsRolOpen=false
	                                 AceGUI:Release(widget) 
									 end)
      ABText:SetTitle("Interfaz de rol")
	  ABText:SetStatusText("WORP - v"..GSIADD_VERSION.." "..GSIADD_DATE)
      ABText:SetPoint("TOP", -250, -50)
      ABText:SetWidth(300)
      ABText:SetHeight(400)
      ABText:SetLayout("Flow")
   local TX1 = AceGUI:Create("EditBox")
      TX1:SetLabel ( "Emote(barra)")
	  TX1:SetCallback ("OnEnterPressed", function() 
	                                          SendChatMessage(TX1:GetText(), "EMOTE" )
										   end)
      TX1:SetText("")
      TX1:SetWidth(260)
      ABText:AddChild (TX1)
   local TX2 = AceGUI:Create("EditBox")
      TX2:SetLabel ( "Emote(asteriscos)")
	  TX2:SetCallback ("OnEnterPressed", function() 
	                                          SendChatMessage("*" .. TX2:GetText() .. "*", "SAY" )
										   end)
      TX2:SetText("")
      TX2:SetWidth(260)
      ABText:AddChild (TX2)
   local LB1 = AceGUI:Create("Label")
      LB1:SetText ( "Dados:")
      LB1:SetWidth(50)
      ABText:AddChild (LB1)

   local TXDMIN = AceGUI:Create("EditBox")
      TXDMIN:SetLabel ( "Min.")
      TXDMIN:SetText(tostring(GSIAddConf["Dmin"]))
	  TXDMIN:SetCallback("OnLeave", function() GSIAddConf["Dmin"] = tonumber(TXDMIN:GetText()) end)
      TXDMIN:SetWidth(50)
	  TXDMIN:DisableButton(true)
      ABText:AddChild (TXDMIN)

   local TXDMAX = AceGUI:Create("EditBox")
      TXDMAX:SetLabel ( "Max.")
      TXDMAX:SetText(tostring(GSIAddConf["Dmax"]))
	  TXDMAX:SetCallback("OnLeave", function() GSIAddConf["Dmax"] = tonumber(TXDMAX:GetText()) end)
      TXDMAX:SetWidth(50)
	  TXDMAX:DisableButton(true)
      ABText:AddChild (TXDMAX)

   local BTN1 = AceGUI:Create("Button")
      BTN1:SetText ( "Lanzar")
      BTN1:SetWidth(80)
	  BTN1:SetCallback("OnClick", function() RandomRoll (tonumber(TXDMIN:GetText()),tonumber(TXDMAX:GetText()))  end)
      ABText:AddChild (BTN1)

  local LB2 = AceGUI:Create("Label")
      local MyText2 = "-- Atributos --\n";
	  if GSIAddConf["Fuerza"] ~= nil and GSIAddConf["Fuerza"] > 0 then
	     MyText2 = MyText2 .. "Fuerza:" .. GSIAddConf["Fuerza"] .. "\n"
	  end
	  if GSIAddConf["Intelecto"] ~= nil and GSIAddConf["Intelecto"] > 0 then
	     MyText2 = MyText2 .. "Intelecto:" .. GSIAddConf["Intelecto"] .. "\n"
	  end
	  if GSIAddConf["Agilidad"] ~= nil and GSIAddConf["Agilidad"] > 0 then
	     MyText2 = MyText2 .. "Agilidad:" .. GSIAddConf["Agilidad"] .. "\n"
	  end
	  if GSIAddConf["Espiritu"] ~= nil and GSIAddConf["Espiritu"] > 0 then
	     MyText2 = MyText2 .. "Espiritu:" .. GSIAddConf["Espiritu"] .. "\n"
	  end
	  if GSIAddConf["Carisma"] ~= nil and GSIAddConf["Carisma"] > 0 then
	     MyText2 = MyText2 .. "Carisma:" .. GSIAddConf["Carisma"] .. "\n"
	  end
	  if GSIAddConf["Resistencia"] ~= nil and GSIAddConf["Resistencia"] > 0 then
	     MyText2 = MyText2 .. "Resistencia:" .. GSIAddConf["Resistencia"] .. "\n"
	  end
      LB2:SetText (MyText2)
      LB2:SetWidth(100)
      ABText:AddChild (LB2)
	  
      local LB3 = AceGUI:Create("Label")
      local MyText3 = "-- Habilidades --\n";
	  if GSIAddConf["Habilidades"] ~= nil then
	     for i,v in ipairs(GSIAddConf["Habilidades"]) do
		    MyText3 = i .. ": " .. v .."\n"
		 end
	  end
	  LB3:SetText (MyText3)
      LB3:SetWidth(160)
      ABText:AddChild (LB3)
	  
      local NOTAS = AceGUI:Create("MultiLineEditBox")
      NOTAS:SetLabel ( "Notas")
	  NOTAS:SetCallback ("OnEnterPressed", function() GSIAddConf["RolNotes"]=NOTAS:GetText() end )
      NOTAS:SetText(GSIAddConf["RolNotes"])
	  NOTAS:SetNumLines(2)
      NOTAS:SetWidth(260)
      ABText:AddChild (NOTAS)
end
function GSIAddNPCSay ( NPCName , NPCGID)
   local AceGUI = LibStub("AceGUI-3.0")
   local ABText = AceGUI:Create("Frame")
      ABText:SetCallback("OnClose",function(widget) AceGUI:Release(widget) end)
      ABText:SetTitle( "Diálogos de NPC")
      ABText:SetPoint("TOP", -250, -50)
      ABText:SetWidth(400)
      ABText:SetHeight(150)
      ABText:SetLayout("Flow")
   local TX1 = AceGUI:Create("MultiLineEditBox")
      TX1:SetLabel ( NPCName .. " dice ...")
	  TX1:SetCallback ("OnEnterPressed", function() 
	                                       if NPCName ~= UnitName("Target") then
										      message ("Debes seleccionar a " .. NPCName .. " primero")
										   else
	                                          SendChatMessage(".npc say " .. TX1:GetText(), "SAY" )
											  TX1:SetText("")
										   end
										   end)
      TX1:SetText("")
	  TX1:SetNumLines(2)
      TX1:SetWidth(300)
      -- TX1:DisableButton(true)
      ABText:AddChild (TX1)
end

--
-- Ficha Social
--
function GSIAddSocial()
   local AceGUI = LibStub("AceGUI-3.0")
   
   local ABText = AceGUI:Create("Frame")
   ABText:SetCallback("OnClose",function(widget) AceGUI:Release(widget) end)
   ABText:SetTitle("GSIAdd - Descripción de Personaje - " .. UnitName("player"))
   ABText:SetPoint("TOP", -250, -50)
   ABText:SetStatusText("WORP - v"..GSIADD_VERSION.." "..GSIADD_DATE)
   ABText:SetWidth(350)
   ABText:SetHeight(450)
   ABText:SetLayout("Flow")
   
   local TX1A = AceGUI:Create("EditBox")
   TX1A:SetLabel ("Título")
   if GSIAddConf["Titulo"] == nil then
      TX1A:SetText("")
   else
      TX1A:SetText(GSIAddConf["Titulo"])
   end
   TX1A:SetCallback("OnLeave", function() GSIAddConf["Titulo"] = TX1A:GetText() end)
   TX1A:SetWidth(150)
   TX1A:DisableButton(true)
   ABText:AddChild (TX1A)

   local TX1 = AceGUI:Create("EditBox")
   TX1:SetLabel ("Nombre")
   TX1:SetText(GSIAddConf["Nombre"])
   TX1:SetCallback("OnLeave", function() GSIAddConf["Nombre"] = TX1:GetText() end)
   TX1:SetWidth(150)
   TX1:DisableButton(true)
   ABText:AddChild (TX1)

   local TX2 = AceGUI:Create("EditBox")
   TX2:SetLabel ("Apellidos")
   TX2:SetText(GSIAddConf["Apellidos"])
   TX2:SetCallback("OnLeave", function() GSIAddConf["Apellidos"] = TX2:GetText() end)
   TX2:SetWidth(300)
   TX2:DisableButton(true)
   ABText:AddChild (TX2)

   local TX3 = AceGUI:Create("EditBox")
   TX3:SetLabel ("Clase")
   if GSIAddConf["Clase"] == nil then
      TX3:SetText(UnitClass("Player"))
   else
      TX3:SetText(GSIAddConf["Clase"])
   end
   TX3:SetCallback("OnLeave", function() GSIAddConf["Clase"] = TX3:GetText() end)
   TX3:SetWidth(300)
   TX3:DisableButton(true)
   ABText:AddChild (TX3)

   local TX4 = AceGUI:Create("EditBox")
   TX4:SetLabel ("Raza")
   if GSIAddConf["Raza"] == nil then
      TX4:SetText(UnitRace("Player"))
   else
      TX4:SetText(GSIAddConf["Raza"])
   end
   TX4:SetCallback("OnLeave", function() GSIAddConf["Raza"] = TX4:GetText() end)
   TX4:SetWidth(300)
   TX4:DisableButton(true)
   ABText:AddChild (TX4)

   local TX5 = AceGUI:Create("EditBox")
   TX5:SetLabel ("Edad (Años)")
   if GSIAddConf["Edad"] == nil then
      TX5:SetText("")
   else
      TX5:SetText(GSIAddConf["Edad"])
   end
   TX5:SetCallback("OnLeave", function() GSIAddConf["Edad"] = TX5:GetText() end)
   TX5:SetWidth(100)
   TX5:DisableButton(true)
   ABText:AddChild (TX5)

   local TX6 = AceGUI:Create("EditBox")
   TX6:SetLabel ("Altura")
   if GSIAddConf["Altura"] == nil then
      TX6:SetText("")
   else
      TX6:SetText(GSIAddConf["Altura"])
   end
   TX6:SetCallback("OnLeave", function() GSIAddConf["Altura"] = TX6:GetText() end)
   TX6:SetWidth(100)
   TX6:DisableButton(true)
   ABText:AddChild (TX6)

   local TX6A = AceGUI:Create("EditBox")
   TX6A:SetLabel ("Peso")
   if GSIAddConf["Peso"] == nil then
      TX6A:SetText("")
   else
      TX6A:SetText(GSIAddConf["Peso"])
   end
   TX6A:SetCallback("OnLeave", function() GSIAddConf["Peso"] = TX6A:GetText() end)
   TX6A:SetWidth(100)
   TX6A:DisableButton(true)
   ABText:AddChild (TX6A)

   local TX3A = AceGUI:Create("MultiLineEditBox")
   TX3A:SetLabel ("Breve descripción")
   TX3A:SetText(GSIAddConf["Rollo"])
   TX3A:SetCallback("OnLeave", function() GSIAddConf["Rollo"] = TX3A:GetText() end)
   TX3A:SetWidth(310)
   TX3A:SetNumLines(8)
   TX3A:SetMaxLetters(220)
   TX3A:DisableButton(true)
   ABText:AddChild (TX3A)
end
-- 
-- Ficha de personaje
--
function GSIAddFicha()
   local AceGUI = LibStub("AceGUI-3.0")
   if GSIAddConf["PuntosAttr"] == nil then
      GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR
   end
   if GSIAddConf["AttrInv"] == nil then
      GSIAddConf["AttrInv"] = 0
   end
   if GSIAddConf["Carisma"] == nil then
      GSIAddConf["Carisma"] = 0
   end
   if GSIAddConf["Resistencia"] == nil then
      GSIAddConf["Resistencia"] = 0
   end
   
   local ABText = AceGUI:Create("Frame")
   ABText:SetCallback("OnClose",function(widget) AceGUI:Release(widget) end)
   ABText:SetTitle("GSIAdd - Ficha de rol - " .. UnitName("player"))
   ABText:SetPoint("TOP", -250, -50)
   ABText:SetStatusText("WORP - v"..GSIADD_VERSION.." "..GSIADD_DATE)
   ABText:SetWidth(450)
   ABText:SetHeight(450)
   ABText:SetLayout("Flow")
   
   local LB1 = AceGUI:Create("Label")
   LB1:SetWidth(380)
   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
     tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	 tostring(GSIAddConf["AttrInv"]) .. " --- ")
   ABText:AddChild (LB1)

   local ATT1 = AceGUI:Create("EditBox")
   ATT1:SetLabel ("Fuerza")
   ATT1:SetWidth (60)
   ATT1:SetText (tostring(GSIAddConf["Fuerza"]))
   ATT1:DisableButton(true)
   ATT1:SetCallback("OnLeave", function() 
                                   GSIAddConf["Fuerza"] = tonumber(ATT1:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT1)

   local ATT2 = AceGUI:Create("EditBox")
   ATT2:SetLabel ("Intelecto")
   ATT2:SetWidth (60)
   ATT2:SetText (tostring(GSIAddConf["Intelecto"]))
   ATT2:DisableButton(true)
   ATT2:SetCallback("OnLeave", function() 
                                   GSIAddConf["Intelecto"] = tonumber(ATT2:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT2)

   local ATT3 = AceGUI:Create("EditBox")
   ATT3:SetLabel ("Agilidad")
   ATT3:SetWidth (60)
   ATT3:SetText (tostring(GSIAddConf["Agilidad"]))
   ATT3:DisableButton(true)
   ATT3:SetCallback("OnLeave", function() 
                                   GSIAddConf["Agilidad"] = tonumber(ATT3:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT3)

   local ATT4 = AceGUI:Create("EditBox")
   ATT4:SetLabel ("Espíritu")
   ATT4:SetText (tostring(GSIAddConf["Espiritu"]))
   ATT4:SetWidth (60)
   ATT4:DisableButton(true)
   ATT4:SetCallback("OnLeave", function() 
                                   GSIAddConf["Espiritu"] = tonumber(ATT4:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT4)

   local ATT5 = AceGUI:Create("EditBox")
   ATT5:SetLabel ("Resistencia")
   ATT5:SetText (tostring(GSIAddConf["Resistencia"]))
   ATT5:SetWidth (60)
   ATT5:DisableButton(true)
   ATT5:SetCallback("OnLeave", function() 
                                   GSIAddConf["Resistencia"] = tonumber(ATT5:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT5)

   local ATT6 = AceGUI:Create("EditBox")
   ATT6:SetLabel ("Carisma")
   ATT6:SetText (tostring(GSIAddConf["Carisma"]))
   ATT6:SetWidth (60)
   ATT6:DisableButton(true)
   ATT6:SetCallback("OnLeave", function() 
                                   GSIAddConf["Carisma"] = tonumber(ATT6:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT6)

   local ATT7 = AceGUI:Create("EditBox")
   if GSIAddConf["HP"] == nil then
      GSIAddConf["HP"] = 50
   end
   ATT7:SetLabel ("(HP)")
   ATT7:SetText (tostring(GSIAddConf["HP"]))
   ATT7:SetWidth (40)
   ATT7:DisableButton(true)
   ATT7:SetCallback("OnLeave", function() 
                                   GSIAddConf["HP"] = tonumber(ATT7:GetText()); 
								   end)
   ABText:AddChild (ATT7)
   
  
   local LBI1 = AceGUI:Create("Label")
   LBI1:SetText ("-- HABILIDADES --")
   LBI1:SetWidth (380)
   ABText:AddChild (LBI1)
   
   local TXI1 = AceGUI:Create("EditBox")
   if GSIAddConf["TXI1"] == nil then
      GSIAddConf["TXI1"] = ""
   end
   TXI1:SetLabel (nil)
   TXI1:SetWidth (130)
   TXI1:SetText(GSIAddConf["TXI1"])
   ABText:AddChild (TXI1)
   local TVI1 = AceGUI:Create("EditBox")
   if GSIAddConf["TVI1"] == nil then
      GSIAddConf["TVI1"] = ""
   end
   TVI1:SetLabel (nil)
   TVI1:SetWidth (50)
   TXI1:SetText(GSIAddConf["TVI1"])
   ABText:AddChild (TVI1)
   local TXI2 = AceGUI:Create("EditBox")
   if GSIAddConf["TXI2"] == nil then
      GSIAddConf["TXI2"] = ""
   end
   TXI2:SetLabel (nil)
   TXI2:SetWidth (130)
   ABText:AddChild (TXI2)
   local TVI2 = AceGUI:Create("EditBox")
   if GSIAddConf["TVI2"] == nil then
      GSIAddConf["TVI2"] = ""
   end
   TVI2:SetLabel (nil)
   TVI2:SetWidth (50)
   ABText:AddChild (TVI2)
   
   local TXI3 = AceGUI:Create("EditBox")
   if GSIAddConf["TXI3"] == nil then
      GSIAddConf["TXI3"] = ""
   end
   TXI3:SetLabel (nil)
   TXI3:SetWidth (130)
   TXI3:SetText(GSIAddConf["TXI3"])
   ABText:AddChild (TXI3)
   local TVI3 = AceGUI:Create("EditBox")
   if GSIAddConf["TVI3"] == nil then
      GSIAddConf["TVI3"] = ""
   end
   TVI3:SetLabel (nil)
   TVI3:SetWidth (50)
   TXI3:SetText(GSIAddConf["TVI3"])
   ABText:AddChild (TVI3)
   local TXI4 = AceGUI:Create("EditBox")
   if GSIAddConf["TXI4"] == nil then
      GSIAddConf["TXI4"] = ""
   end
   TXI4:SetLabel (nil)
   TXI4:SetWidth (130)
   ABText:AddChild (TXI4)
   local TVI4 = AceGUI:Create("EditBox")
   if GSIAddConf["TVI4"] == nil then
      GSIAddConf["TVI4"] = ""
   end
   TVI4:SetLabel (nil)
   TVI4:SetWidth (50)
   ABText:AddChild (TVI4)
   
   local TXI5 = AceGUI:Create("EditBox")
   if GSIAddConf["TXI5"] == nil then
      GSIAddConf["TXI5"] = ""
   end
   TXI5:SetLabel (nil)
   TXI5:SetWidth (130)
   TXI5:SetText(GSIAddConf["TXI5"])
   ABText:AddChild (TXI5)
   local TVI5 = AceGUI:Create("EditBox")
   if GSIAddConf["TVI5"] == nil then
      GSIAddConf["TVI5"] = ""
   end
   TVI5:SetLabel (nil)
   TVI5:SetWidth (50)
   TXI5:SetText(GSIAddConf["TVI5"])
   ABText:AddChild (TVI5)
   local TXI6 = AceGUI:Create("EditBox")
   if GSIAddConf["TXI6"] == nil then
      GSIAddConf["TXI6"] = ""
   end
   TXI6:SetLabel (nil)
   TXI6:SetWidth (130)
   ABText:AddChild (TXI6)
   local TVI6 = AceGUI:Create("EditBox")
   if GSIAddConf["TVI6"] == nil then
      GSIAddConf["TVI6"] = ""
   end
   TVI6:SetLabel (nil)
   TVI6:SetWidth (50)
   ABText:AddChild (TVI6)

end
function GSIAddFicha_old()
   local AceGUI = LibStub("AceGUI-3.0")
   local AttValues = { 
                       [0] = "0", [1] = "1", [2] = "2", [3] = "3", [4] = "4", 
					   [5] = "5", [6] = "6", [7] = "7", [8] = "8", [9] = "9", 
					   [10] = "10", [11] = "11", [12] = "12", [13] = "13", [14] = "14", 
					   [15] = "15", [16] = "16", [17] = "17", [18] = "18", [19] = "19", 
					   [20] = "20", [21] = "21", [22] = "22", [23] = "23", [24] = "24", 
					   [25] = "25", [26] = "26", [27] = "27", [28] = "28", [29] = "29", 
					   [30] = "30", 
                       [31] = "31", 
					   [32] = "32", 
					   [33] = "33", 
					   [34] = "34", 
					   [35] = "35",
                       [36] = "36", 
                       [37] = "37", 
					   [38] = "38", 
					   [39] = "39", 
					   }
   
   if GSIAddConf["PuntosAttr"] == nil then
      GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR
   end
   if GSIAddConf["AttrInv"] == nil then
      GSIAddConf["AttrInv"] = 0
   end
   if GSIAddConf["Carisma"] == nil then
      GSIAddConf["Carisma"] = 0
   end
   if GSIAddConf["Resistencia"] == nil then
      GSIAddConf["Resistencia"] = 0
   end
   
   local ABText = AceGUI:Create("Frame")
   ABText:SetCallback("OnClose",function(widget) AceGUI:Release(widget) end)
   ABText:SetTitle("GSIAdd - Ficha de rol - " .. UnitName("player"))
   ABText:SetPoint("TOP", -250, -50)
   ABText:SetStatusText("WORP - v"..GSIADD_VERSION.." "..GSIADD_DATE)
   ABText:SetWidth(400)
   ABText:SetHeight(450)
   ABText:SetLayout("Flow")
   
   local LB1 = AceGUI:Create("Label")
   LB1:SetWidth(380)
   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
     tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	 tostring(GSIAddConf["AttrInv"]) .. " --- ")
   ABText:AddChild (LB1)

   local ATT1 = AceGUI:Create("Dropdown")
   ATT1:SetLabel ("Fuerza")
   ATT1:SetWidth (60)
   ATT1:SetList  (AttValues)
   ATT1:SetCallback("OnValueChanged", function() 
                                   GSIAddConf["Fuerza"] = tonumber(ATT1:GetValue()); 
								   -- print ( tostring(GSIAddConf["Fuerza"])  .. ":" .. ATT1:GetValue() );
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ATT1:SetText (GSIAddConf["Fuerza"])
   ATT1:SetValue (GSIAddConf["Fuerza"])
   ABText:AddChild (ATT1)

   local ATT2 = AceGUI:Create("Dropdown")
   ATT2:SetLabel ("Intelecto")
   ATT2:SetText (GSIAddConf["Intelecto"])
   ATT2:SetWidth (60)
   ATT2:SetList  (AttValues)
   ATT2:SetCallback("OnValueChanged", function() 
                                   GSIAddConf["Intelecto"] = tonumber(ATT2:GetValue()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT2)

   local ATT3 = AceGUI:Create("Dropdown")
   ATT3:SetLabel ("Agilidad")
   ATT3:SetText (GSIAddConf["Agilidad"])
   ATT3:SetWidth (60)
   ATT3:SetList  (AttValues)
   ATT3:SetCallback("OnValueChanged", function() 
                                   GSIAddConf["Agilidad"] = tonumber(ATT3:GetValue()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT3)

   local ATT4 = AceGUI:Create("Dropdown")
   ATT4:SetLabel ("Espíritu")
   ATT4:SetText (GSIAddConf["Espiritu"])
   ATT4:SetWidth (60)
   ATT4:SetList  (AttValues)
   ATT4:SetCallback("OnValueChanged", function() 
                                   GSIAddConf["Espiritu"] = tonumber(ATT4:GetValue()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT4)

   local ATT5 = AceGUI:Create("Dropdown")
   ATT5:SetLabel ("Resistencia")
   ATT5:SetText (GSIAddConf["Resistencia"])
   ATT5:SetWidth (60)
   ATT5:SetList  (AttValues)
   ATT5:SetCallback("OnValueChanged", function() 
                                   GSIAddConf["Resistencia"] = tonumber(ATT5:GetValue()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT5)

   local ATT6 = AceGUI:Create("Dropdown")
   ATT6:SetLabel ("Carisma")
   ATT6:SetText (GSIAddConf["Carisma"])
   ATT6:SetWidth (60)
   ATT6:SetList  (AttValues)
   ATT6:SetCallback("OnValueChanged", function() 
                                   GSIAddConf["Carisma"] = tonumber(ATT6:GetValue()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT6)

   local LBI1 = AceGUI:Create("Label")
   LBI1:SetText ("-- PUNTOS DE INSTINTO --")
   LBI1:SetWidth (380)
   ABText:AddChild (LBI1)
   
   local TXI1 = AceGUI:Create("EditBox")
   if GSIAddConf["TXI1"] == nil then
      GSIAddConf["TXI1"] = ""
   end
   TXI1:SetLabel ("Item")
   TXI1:SetWidth (140)
   TXI1:SetText(GSIAddConf["TXI1"])
   ABText:AddChild (TXI1)
   local TVI1 = AceGUI:Create("EditBox")
   if GSIAddConf["TVI1"] == nil then
      GSIAddConf["TVI1"] = ""
   end
   TVI1:SetLabel ("Valor")
   TVI1:SetWidth (50)
   TXI1:SetText(GSIAddConf["TVI1"])
   ABText:AddChild (TVI1)
   local TDI1 = AceGUI:Create("EditBox")
   if GSIAddConf["TDI1"] == nil then
      GSIAddConf["TDI1"] = ""
   end
   TDI1:SetLabel ("Notas")
   TDI1:SetWidth (140)
   TXI1:SetText(GSIAddConf["TVI1"])
   ABText:AddChild (TDI1)

   local TXI2 = AceGUI:Create("EditBox")
   TXI2:SetWidth (140)
   TXI2:SetLabel (nil)
   ABText:AddChild (TXI2)
   local TVI2 = AceGUI:Create("EditBox")
   TVI2:SetWidth (50)
   TVI2:SetLabel (nil)
   ABText:AddChild (TVI2)
   local TDI2 = AceGUI:Create("EditBox")
   TDI2:SetWidth (140)
   TDI2:SetLabel (nil)
   ABText:AddChild (TDI2)

end
function GSIAddQueryFicha ( PlayerName )
   SendAddonMessage("GSIADD", "DUMPV:" .. UnitName("Player") ..":2:3:4:5:6:7", "WHISPER", PlayerName )
end
function GSITstFrame ()
   local backdrop = {
     -- path to the background texture
     bgFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Background",  
     -- path to the border texture
     edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
     -- true to repeat the background texture to fill the frame, false to scale it
     tile = true,
     -- size (width or height) of the square repeating background tiles (in pixels)
     tileSize = 32,
     -- thickness of edge segments and square size of edge corners (in pixels)
     edgeSize = 32,
     -- distance from the edges of the frame to those of the background texture (in pixels)
     insets = {
       left = 11,
       right = 12,
       top = 12,
       bottom = 11
     }
   }
   local ThisFrame = CreateFrame("Frame","ThisFrame",UIParent)
   ThisFrame:SetPoint("TOP",300,-30)
   ThisFrame:SetWidth(100)
   ThisFrame:SetHeight(50)
   ThisFrame:SetBackdrop(backdrop)
   
end
function GSIAdd_Ast ( self, event, msg, ... )
   local arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14 = ...
--   print ("arg2=[" .. arg2 .."]")
--   print ("arg3=[" .. arg3 .."]")
--   print ("arg4=[" .. arg4 .."]")
--   print ("arg5=[" .. arg5 .."]")
--   print ("arg6=[" .. arg6 .."]")
--   print ("arg7=[" .. arg7 .."]")
--   print ("arg8=[" .. arg8 .."]")
--   print ("arg9=[" .. arg9 .."]")
--   print ("arg10=[" .. arg10 .."]")
--   print ("arg11=[" .. arg11 .."]")
--   print ("arg12=[" .. arg12 .."]")
--   print ("arg13=[" .. arg13 .."]")
--   print ("arg14=[" .. tostring(arg14) .."]")
--   print ("arg15=[" .. arg15 .."]")
   msg = string.gsub(msg,"%<.-%>","|cffff8866 %1|r")
   msg = string.gsub(msg,"%*.-%*","|cffff8866 %1|r")
   return false, msg, ...
end

