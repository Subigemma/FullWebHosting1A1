--
-- MSG: 
-- 
--   ALRTP -> Request Player desc.
--   ALRTG -> Send Player desc
--   DUMPV -> Request player stats
--   DUMPE -> Send Player stats


function GSIAddProcessMsg (Message, Sender)
   local GSI_Command, GSI_Actor, GSI_Target, GSI_SNum1, GSI_SNum2, GSI_SNum3, GSI_FreeText = strsplit ( ":", Message )
   local GSI_Num1 = tonumber(GSI_SNum1)   
   local GSI_Num2 = tonumber(GSI_SNum2)   
   local GSI_Num3 = tonumber(GSI_SNum3) 
   -- print ( "Rebut [" .. GSI_Command .. "][" .. Sender .. "]" )   
   --
   -- Process command
   --
   local MyFocus = " "
   local MyRealm = GetRealmName()
   if MyRealm ~= "WorldOfRoleplay" then
      print ( "WORP: (c) Violation ...")
	  return
   end
   if GSI_Command == "ALRTP" then
      if GSIAddConf["Titulo"] == nil or GSIAddConf["Titulo"] == "" then
	     MyTitulo = ""
	  else
	     MyTitulo = GSIAddConf["Titulo"]
	  end
      if GSIAddConf["Edad"] == nil or GSIAddConf["Edad"] == "" then
	     MyEdad = ""
	  else
	     MyEdad = GSIAddConf["Edad"] .. " Años"
	  end
      if GSIAddConf["Altura"] == nil or GSIAddConf["Altura"] == "" then
	     MyAltura = ""
	  else
	     MyAltura = GSIAddConf["Altura"] .. " m"
	  end
      if GSIAddConf["Peso"] == nil or GSIAddConf["Peso"] == "" then
	     MyPeso = ""
	  else
	     MyPeso = GSIAddConf["Peso"] .. " Kg"
	  end
	  
	  if UnitName("target") ~= nil then
	     MyFocus = " ->" .. UnitName("target")
	  end
	  
	  local MyGuild = GetGuildInfo("player")
	  if MyGuild == nil then
	     MyGuild = ""
	  end
	     
      SendAddonMessage("GSIADD", 
	  "ALRTG:" .. GSIAddConf["Nombre"] ..":" 
	           .. MyFocus .. ":"
			   .. GSIADD_VERSION .. ":"
			   .. MyGuild .. ":"
			   .. " " ..": | | | " 
               , "WHISPER", GSI_Actor )

	  
      SendAddonMessage("GSIADD", "SHEAD:" .. 
                    MyTitulo .. ":" ..
                    GSIAddConf["Nombre"] .. ":" ..
                    GSIAddConf["Apellidos"] .. ":" ..
                    GSIAddConf["Clase"] .. ":" ..
                    GSIAddConf["Raza"] .. ":" ..
                    MyEdad .. "|" .. MyAltura .. "|" .. MyPeso , "WHISPER", GSI_Actor )
					
      SendAddonMessage("GSIADD", "SBODY:1:2:3:4:5:" .. 
                    GSIAddConf["Rollo"], "WHISPER", GSI_Actor )
	   
   elseif GSI_Command == "SHEAD" then
      local SuEdad, SuAltura, SuPeso = strsplit ( "|", GSI_FreeText )
	  local MyInfo = { Titulo = tostring(GSI_Actor), 
	                   Prenom = tostring(GSI_Target), 
					   Nom = tostring(GSI_SNum1), 
					   Class = tostring(GSI_SNum2),
					   Race = tostring(GSI_SNum3),
					   Edad = tostring(SuEdad),
					   Altura = tostring(SuAltura),
					   Peso = tostring(SuPeso)}
	  local MyIndex = "H_" .. Sender
   	  KChars[MyIndex] = MyInfo

   elseif GSI_Command == "SBODY" then
	  local MyIndex = "B_" .. Sender
   	  KChars[MyIndex] = GSI_FreeText
	  
   elseif GSI_Command == "ALRTG" then
      local MyIndexH = "H_" .. Sender
      local MyIndexB = "B_" .. Sender
	  local IsApp = ""
	  local Rollo = ""
	  if KChars[MyIndexH] == nil then
	     GameTooltip:AddLine ("Version incompatible de GSIAdd")
         GameTooltip:Show ()
	     return
	  end	 
	  GameTooltip:ClearLines()
     
	  
	  local GuildStr = ""
	  if ( GSI_SNum2 ~= "" ) then
	     GuildStr = " (" .. GSI_SNum2 .. ")"
	     if GSI_SNum2 == "staff" then
	        IsApp = "\n(Aprovador de fichas)"
	     end
	  end
      GameTooltip:AddLine( KChars[MyIndexH].Titulo .. " " .. KChars[MyIndexH].Prenom .. " " .. KChars[MyIndexH].Nom .. GuildStr, 0, 127, 127)
	  GameTooltip:AddLine( KChars[MyIndexH].Class .. " - " .. KChars[MyIndexH].Race .. "  [".. 
	                       KChars[MyIndexH].Edad .."/" .. KChars[MyIndexH].Altura .. "/" .. KChars[MyIndexH].Peso .. "]\n", 0, 127, 0)

      if KChars[MyIndexB] ~= nil then
	     Rollo = KChars[MyIndexB]
	  end	 
      GameTooltip:AddLine( Rollo, 127, 127, 127, true)
      GameTooltip:AddLine( "\n-----------------------------------------------[WORP v"..GSI_SNum1.."]\n", 127, 127, 0)
      GameTooltip:AddLine( GSI_Target .. "|cffff8866" .. IsApp, 255, 255, 0)
      GameTooltip:Show ()

   elseif GSI_Command == "DUMPV" then
      SendAddonMessage("GSIADD", 
	  "DUMPE:" .. GSIAddConf["Nombre"] ..":" 
	           .. GSIAddConf["Apellidos"] .. ":" 
			   .. tostring(GSIAddConf["PuntosAttr"]) .. ":" 
			   .. tostring(GSIAddConf["AttrInv"]) .. ":6:" 
			   .. GSIAddConf["Fuerza"] .. "|" 
			   .. GSIAddConf["Intelecto"] .. "|" 
			   .. GSIAddConf["Espiritu"] .. "|" 
			   .. GSIAddConf["Agilidad"] .. "|"
			   .. GSIAddConf["Resistencia"] .. "|"
			   .. GSIAddConf["Carisma"] 
			   ,
	   "WHISPER", GSI_Actor )
   elseif GSI_Command == "DUMPE" then
   
      local Fuerza, Intelecto, Espiritu, Agilidad, Resistencia, Carisma, Rest = strsplit ( "|", GSI_FreeText )
      local AceGUI = LibStub("AceGUI-3.0")
      local ABText = AceGUI:Create("Frame")
      ABText:SetCallback("OnClose",function(widget) AceGUI:Release(widget) end)
      ABText:SetTitle("GSIAdd - Ficha de rol - " .. GSI_Actor)
      ABText:SetPoint("TOP", -250, -50)
      ABText:SetStatusText("WORP - v"..GSIADD_VERSION.." "..GSIADD_DATE)
      ABText:SetWidth(350)
      ABText:SetHeight(450)
      ABText:SetLayout("Flow")   
	  local LB1 = AceGUI:Create("Label")
      LB1:SetWidth(300)
      LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
      GSI_SNum1 .. " - Invertidos: " .. 
	  GSI_SNum2 .. "\n" )
      ABText:AddChild (LB1)
	  
	  local LB2 = AceGUI:Create("Label")
      LB2:SetWidth(300)
	  LB2:SetFont ( "Fonts\\ARIALN.TTF", 10)
      LB2:SetText  ("Fuerza: " .. Fuerza .. 
	                " Intelecto: " .. Intelecto .. 
					" Espíritu: " .. Espiritu .. 
					" Agilidad: " .. Agilidad ..
					" Resisténcia: " .. Resistencia ..
					" Carisma: " .. Carisma	)
      ABText:AddChild (LB2)
	  
   elseif GSI_Command == "SHALRT" then
      if GSI_Target == UnitName ("Player") then
         GSIAddAlert ( GSI_Actor, GSI_FreeText )
	  end
   end
end

--
-- COMMUNICATIONS END
--

