GSIAdd_frame = CreateFrame ("Button", "GSIAdd", UIParent,"UIPanelButtonTemplate" )
GSIAddMenuFrame = CreateFrame("Frame", "GSIAddMenuFrame", UIParent, "UIDropDownMenuTemplate")
GSIAddMenuFrame:SetPoint("TOPLEFT", UIParent, 120, 50)
CloseDropDownMenus()


function GSIAdd_frame:OnEvent(event, ...)
  local arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12 = ...;
  if event == "ADDON_LOADED" and arg1 == "GSIAdd" then
	GSILoadVars()
    -- GSIAdd_Hook_FEvent()
  elseif event == "CHAT_MSG_ADDON" then
	GSIAddProcessMsg( arg2 , arg4)
  elseif event == "UPDATE_MOUSEOVER_UNIT" then
    SendAddonMessage("GSIADD", "ALRTP:" .. UnitName("Player") .. ":3:4:5:6:7", "WHISPER", UnitName("mouseover"))
  elseif event == "CHAT_MSG_SAY" then
    if arg6 == "GM" and arg5 == UnitName("Player") and arg1 == ("CHKGMPLY") then
	   print ("CHK-GM")
	   return
	end
     -- print ( "arg1 =[" .. arg1 .."](Texte)")
     -- print ( "arg2 =[" .. arg2 .."](Player-Roiaumme")
     -- print ( "arg3 =[" .. arg3 .."]")
     -- print ( "arg4 =[" .. arg4 .."]")
     -- print ( "arg5 =[" .. arg5 .."]")
     -- print ( "arg6 =[" .. arg6 .."](Player)")
     -- print ( "arg7 =[" .. arg7 .."]")
     -- print ( "arg8 =[" .. arg8 .."]")
     -- print ( "arg9 =[" .. arg9 .."]")
  end
  

end
function GSIAdd_ToggleM ( )
   local GSIAddMenu
   local MyRealm = GetRealmName()
   if MyRealm ~= "WorldOfRoleplay" then
      print ( "WORP: (c) Violation ...")
	  return
   end
   GSIAddMenu = {
         { text = "Social", func = function() GSIAddSocial(); end},
         { text = "Interfaz de rol", func = function() GSIShowRolGUID(); end},
         { text = "Ficha de personaje", func = function() GSIAddFicha(); end},
	   }
   if UnitName("Target") ~= nil and UnitIsPlayer ("Target") then
      table.insert ( GSIAddMenu, { text = "Ver ficha de " .. UnitName("Target"), func = function() GSIAddQueryFicha(UnitName("Target")); end} )
 	  table.insert ( GSIAddMenu, { text = "Toque de atencion a " .. UnitName("Target"), 
	  func = function() 
	      StaticPopupDialogs ["GSIADD_ALERT"].text = "Toque de atencion a" .. UnitName("Target")
	      StaticPopup_Show ("GSIADD_ALERT")
	 end} )
   end
   if UnitName("Target") ~= nil and UnitIsPlayer ("Target") == false then
      table.insert ( GSIAddMenu, { text = UnitName("Target") .. " dice ..", func = function() GSIAddNPCSay(UnitName("Target"), UnitGUID("Target")); end} )
   end
	
   EasyMenu(GSIAddMenu, GSIAddMenuFrame, GSIAddMenuFrame, 0 , 0, "MENU")
end   

function GSIAdd_ToggleM_Lite ( )
   local MyRealm = GetRealmName()
   if MyRealm ~= "WorldOfRoleplay" then
      print ( "WORP: (c) Violation ...")
	  return
   end
   local GSIAddMenu = {
       { text = "Social", func = function() GSIAddSocial(); end},
       { text = "Interfaz de rol", func = function() GSIShowRolGUID(); end},
	   }
   if UnitName("Target") ~= nil and UnitIsPlayer ("Target") == false then
      table.insert ( GSIAddMenu, { text = UnitName("Target") .. " dice ..", func = function() GSIAddNPCSay(UnitName("Target"), UnitGUID("Target")); end} )
   end
   EasyMenu(GSIAddMenu, GSIAddMenuFrame, GSIAddMenuFrame, 0 , 0, "MENU")
end   


GSIAdd_frame:SetPoint("TOPLEFT", 80, 0)
GSIAdd_frame:SetWidth(80)
GSIAdd_frame:SetHeight(20)
GSIAdd_frame:SetText("WORP")
GSIAdd_frame:RegisterEvent("ADDON_LOADED")    -- Fired when saved variables are loaded
GSIAdd_frame:RegisterEvent("PLAYER_LOGOUT")   -- Fired when about to log out
GSIAdd_frame:RegisterEvent("CHAT_MSG_ADDON")  -- When a MSG_ADDOD
GSIAdd_frame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_GUILD", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_YELL", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY_LEADER", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_LEADER", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_OFFICER", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", GSIAdd_Ast)
GSIAdd_frame:SetScript("OnEvent", GSIAdd_frame.OnEvent)
GSIAdd_frame:SetScript("OnClick", GSIAdd_ToggleM )

MyRc = RegisterAddonMessagePrefix("GSIADD")




