HPShow=false;
MPShow=true;
local function HPToggle (self, button)
   if HPShow == true then 
      self.HPVal:Hide()
      HPShow = false
   else
      self.HPVal:Show()
      HPShow = true
   end 
end
MyHPBar = CreateFrame("StatusBar", nil, UIParent)
MyHPBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
MyHPBar:GetStatusBarTexture():SetHorizTile(true)
MyHPBar:SetMinMaxValues(0, 100)
MyHPBar:SetWidth(200)
MyHPBar:SetHeight(12)
MyHPBar:SetPoint("TOPLEFT", 230, 0)
MyHPBar:SetStatusBarColor(0,1,1)
MyHPBar.HPVal = MyHPBar:CreateFontString(nil, "OVERLAY")
MyHPBar.HPVal:SetPoint("LEFT", MyHPBar, "LEFT", -50, 0)
MyHPBar.HPVal:SetFont("Fonts\\FRIZQT__.TTF", 10, "MONOCHROME")
MyHPBar.HPVal:SetJustifyH("LEFT")
MyHPBar.HPVal:SetShadowOffset(1, -1)
MyHPBar.HPVal:SetTextColor(1, 1, 1)



MyMPBar = CreateFrame("StatusBar", nil, UIParent)
MyMPBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
MyMPBar:GetStatusBarTexture():SetHorizTile(true)
MyMPBar:SetMinMaxValues(0, 100)
MyMPBar:SetWidth(200)
MyMPBar:SetHeight(12)
MyMPBar:SetPoint("TOPLEFT", 230, -12)
MyMPBar:SetStatusBarColor(1,0,1)
MyMPBar.MPVal = MyMPBar:CreateFontString(nil, "OVERLAY")
MyMPBar.MPVal:SetPoint("LEFT", MyMPBar, "LEFT", -50, 0)
MyMPBar.MPVal:SetFont("Fonts\\FRIZQT__.TTF", 10, "MONOCHROME")
MyMPBar.MPVal:SetJustifyH("LEFT")
MyMPBar.MPVal:SetShadowOffset(1, -1)
MyMPBar.MPVal:SetTextColor(1, 1, 1)

IsBarShow = true

function GSIAddSendHP( HP , Target)
SendAddonMessage("GSIADD", 
	  "LTRHP:" .. UnitName("player") .. ":" .. Target .. ":" .. tostring(HP) .. ":0:0:" 
               , "WHISPER", Target )
end
function GSIAddSendMP( MP , Target )
SendAddonMessage("GSIADD", 
	  "LTRMP:" .. UnitName("player") .. ":" .. Target .. ":" .. tostring(MP) .. ":0:0:" 
               , "WHISPER", Target )
end

function GSIAddUpdateBars()
    if GSIAddConf["HP"] > GSIAddConf["HPMAX"] then
	   GSIAddConf["HP"] = GSIAddConf["HPMAX"]
	end
    if GSIAddConf["MP"] > GSIAddConf["MPMAX"] then
	   GSIAddConf["MP"] = GSIAddConf["MPMAX"]
	end	
    MyHPBar:SetValue(GSIAddConf["HP"])
	MyHPBar.HPVal:SetText("HP:" .. tostring(GSIAddConf["HP"]) .. "/" .. tostring(GSIAddConf["HPMAX"]))
    MyMPBar:SetValue(GSIAddConf["MP"])
	MyMPBar.MPVal:SetText("PE:" .. tostring(GSIAddConf["MP"]) .. "/" .. tostring(GSIAddConf["HPMAX"]))
end
function GSIAddAlert ( Sender, MSG )
   message( Sender .. " te dice:\n" .. MSG)
end
function GSIAddNPCSay ( NPCName , NPCGID)
  local AceGUI = LibStub("AceGUI-3.0")
  local ABText = AceGUI:Create("Frame")
  ABText:SetCallback("OnClose",function(widget) AceGUI:Release(widget) end)
  ABText:SetTitle( "Diálogos de NPC")
  ABText:SetPoint("TOP", -250, -50)
  ABText:SetWidth(400)
  ABText:SetHeight(150)
  ABText:SetLayout("Flow")
  local TX1 = AceGUI:Create("MultiLineEditBox")
  TX1:SetLabel ( NPCName .. " dice ...")
  TX1:SetCallback ("OnEnterPressed", function() 
                                      if NPCName ~= UnitName("Target") then
  								       message ("Debes seleccionar a " .. NPCName .. " primero")
  								      else
                                       SendChatMessage(".npc say " .. TX1:GetText(), "SAY" )
  									  TX1:SetText("")
  								      end
  								     end)
  TX1:SetText("")
  TX1:SetNumLines(2)
  TX1:SetWidth(300)
  ABText:AddChild (TX1)
end

--
-- Ficha Social
--
function GSIAddSocial()
   local AceGUI = LibStub("AceGUI-3.0")
   
   local ABText = AceGUI:Create("Frame")
   ABText:SetCallback("OnClose",function(widget) AceGUI:Release(widget) end)
   ABText:SetTitle("GSIAdd - Descripción de Personaje - " .. UnitName("player"))
   ABText:SetPoint("TOP", -250, -50)
   ABText:SetStatusText("GSIAdd - v"..GSIADD_VERSION.." "..GSIADD_DATE)
   ABText:SetWidth(350)
   ABText:SetHeight(450)
   ABText:SetLayout("Flow")
   
   local TX1A = AceGUI:Create("EditBox")
   TX1A:SetLabel ("Título")
   if GSIAddConf["Titulo"] == nil then
      TX1A:SetText("")
   else
      TX1A:SetText(GSIAddConf["Titulo"])
   end
   TX1A:SetCallback("OnLeave", function() GSIAddConf["Titulo"] = TX1A:GetText() end)
   TX1A:SetWidth(150)
   TX1A:DisableButton(true)
   ABText:AddChild (TX1A)

   local TX1 = AceGUI:Create("EditBox")
   TX1:SetLabel ("Nombre")
   TX1:SetText(GSIAddConf["Nombre"])
   TX1:SetCallback("OnLeave", function() GSIAddConf["Nombre"] = TX1:GetText() end)
   TX1:SetWidth(150)
   TX1:DisableButton(true)
   ABText:AddChild (TX1)

   local TX2 = AceGUI:Create("EditBox")
   TX2:SetLabel ("Apellidos")
   TX2:SetText(GSIAddConf["Apellidos"])
   TX2:SetCallback("OnLeave", function() GSIAddConf["Apellidos"] = TX2:GetText() end)
   TX2:SetWidth(300)
   TX2:DisableButton(true)
   ABText:AddChild (TX2)

   local TX3 = AceGUI:Create("EditBox")
   TX3:SetLabel ("Clase")
   if GSIAddConf["Clase"] == nil then
      TX3:SetText(UnitClass("Player"))
   else
      TX3:SetText(GSIAddConf["Clase"])
   end
   TX3:SetCallback("OnLeave", function() GSIAddConf["Clase"] = TX3:GetText() end)
   TX3:SetWidth(300)
   TX3:DisableButton(true)
   ABText:AddChild (TX3)

   local TX4 = AceGUI:Create("EditBox")
   TX4:SetLabel ("Raza")
   if GSIAddConf["Raza"] == nil then
      TX4:SetText(UnitRace("Player"))
   else
      TX4:SetText(GSIAddConf["Raza"])
   end
   TX4:SetCallback("OnLeave", function() GSIAddConf["Raza"] = TX4:GetText() end)
   TX4:SetWidth(300)
   TX4:DisableButton(true)
   ABText:AddChild (TX4)

   local TX5 = AceGUI:Create("EditBox")
   TX5:SetLabel ("Edad (Años)")
   if GSIAddConf["Edad"] == nil then
      TX5:SetText("")
   else
      TX5:SetText(GSIAddConf["Edad"])
   end
   TX5:SetCallback("OnLeave", function() GSIAddConf["Edad"] = TX5:GetText() end)
   TX5:SetWidth(100)
   TX5:DisableButton(true)
   ABText:AddChild (TX5)

   local TX6 = AceGUI:Create("EditBox")
   TX6:SetLabel ("Altura")
   if GSIAddConf["Altura"] == nil then
      TX6:SetText("")
   else
      TX6:SetText(GSIAddConf["Altura"])
   end
   TX6:SetCallback("OnLeave", function() GSIAddConf["Altura"] = TX6:GetText() end)
   TX6:SetWidth(100)
   TX6:DisableButton(true)
   ABText:AddChild (TX6)

   local TX6A = AceGUI:Create("EditBox")
   TX6A:SetLabel ("Peso")
   if GSIAddConf["Peso"] == nil then
      TX6A:SetText("")
   else
      TX6A:SetText(GSIAddConf["Peso"])
   end
   TX6A:SetCallback("OnLeave", function() GSIAddConf["Peso"] = TX6A:GetText() end)
   TX6A:SetWidth(100)
   TX6A:DisableButton(true)
   ABText:AddChild (TX6A)

   local TX3A = AceGUI:Create("MultiLineEditBox")
   TX3A:SetLabel ("Breve descripción")
   TX3A:SetText(GSIAddConf["Rollo"])
   TX3A:SetCallback("OnLeave", function() GSIAddConf["Rollo"] = TX3A:GetText() end)
   TX3A:SetWidth(310)
   TX3A:SetNumLines(8)
   TX3A:SetMaxLetters(220)
   TX3A:DisableButton(true)
   ABText:AddChild (TX3A)
end
-- 
-- Ficha de personaje
--
function GSIAddFicha()
   local AceGUI = LibStub("AceGUI-3.0")
   if GSIAddConf["PuntosAttr"] == nil then
      GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR
   end
   if GSIAddConf["AttrInv"] == nil then
      GSIAddConf["AttrInv"] = 0
   end
   if GSIAddConf["Carisma"] == nil then
      GSIAddConf["Carisma"] = 0
   end
   if GSIAddConf["Resistencia"] == nil then
      GSIAddConf["Resistencia"] = 0
   end
   
   local ABText = AceGUI:Create("Frame")
   ABText:SetCallback("OnClose",function(widget) 
                                GSIAddUpdateBars()
                                AceGUI:Release(widget) end)
   ABText:SetTitle("GSIAdd - Ficha de rol - " .. UnitName("player"))
   ABText:SetPoint("TOP", -250, -50)
   ABText:SetStatusText("GSIAdd - v"..GSIADD_VERSION.." "..GSIADD_DATE)
   ABText:SetWidth(420)
   ABText:SetHeight(450)
   ABText:SetLayout("Flow")
   
   local LB1 = AceGUI:Create("Label")
   LB1:SetWidth(380)
   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
     tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	 tostring(GSIAddConf["AttrInv"]) .. " --- ")
   ABText:AddChild (LB1)

   local ATT1 = AceGUI:Create("EditBox")
   ATT1:SetLabel ("Fuerza")
   ATT1:SetWidth (60)
   ATT1:SetText (tostring(GSIAddConf["Fuerza"]))
   ATT1:DisableButton(true)
   ATT1:SetCallback("OnLeave", function() 
                                   GSIAddConf["Fuerza"] = tonumber(ATT1:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT1)

   local ATT2 = AceGUI:Create("EditBox")
   ATT2:SetLabel ("Intelecto")
   ATT2:SetWidth (60)
   ATT2:SetText (tostring(GSIAddConf["Intelecto"]))
   ATT2:DisableButton(true)
   ATT2:SetCallback("OnLeave", function() 
                                   GSIAddConf["Intelecto"] = tonumber(ATT2:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT2)

   local ATT3 = AceGUI:Create("EditBox")
   ATT3:SetLabel ("Agilidad")
   ATT3:SetWidth (60)
   ATT3:SetText (tostring(GSIAddConf["Agilidad"]))
   ATT3:DisableButton(true)
   ATT3:SetCallback("OnLeave", function() 
                                   GSIAddConf["Agilidad"] = tonumber(ATT3:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT3)

   local ATT4 = AceGUI:Create("EditBox")
   ATT4:SetLabel ("Espíritu")
   ATT4:SetText (tostring(GSIAddConf["Espiritu"]))
   ATT4:SetWidth (60)
   ATT4:DisableButton(true)
   ATT4:SetCallback("OnLeave", function() 
                                   GSIAddConf["Espiritu"] = tonumber(ATT4:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT4)

   local ATT5 = AceGUI:Create("EditBox")
   ATT5:SetLabel ("Resistencia")
   ATT5:SetText (tostring(GSIAddConf["Resistencia"]))
   ATT5:SetWidth (60)
   ATT5:DisableButton(true)
   ATT5:SetCallback("OnLeave", function() 
                                   GSIAddConf["Resistencia"] = tonumber(ATT5:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT5)

   local ATT6 = AceGUI:Create("EditBox")
   ATT6:SetLabel ("Carisma")
   ATT6:SetText (tostring(GSIAddConf["Carisma"]))
   ATT6:SetWidth (60)
   ATT6:DisableButton(true)
   ATT6:SetCallback("OnLeave", function() 
                                   GSIAddConf["Carisma"] = tonumber(ATT6:GetText()); 
								   GSIAddConf["AttrInv"] = GSIAddConf["Fuerza"] + 
								                           GSIAddConf["Intelecto"] + 
								                           GSIAddConf["Carisma"] + 
								                           GSIAddConf["Resistencia"] + 
														   GSIAddConf["Agilidad"] +
														   GSIAddConf["Espiritu"];
								   GSIAddConf["PuntosAttr"] = GSI_MAX_ATTR - GSIAddConf["AttrInv"];
								   LB1:SetText  ("--- PUNTOS DE ATRIBUTO - Totales: " .. 
                                      tostring(GSIAddConf["PuntosAttr"]) .. " - Invertidos: " .. 
	                                  tostring(GSIAddConf["AttrInv"]));
								   end)
   ABText:AddChild (ATT6)

   local ATT7 = AceGUI:Create("EditBox")
   if GSIAddConf["HP"] == nil then
      GSIAddConf["HP"] = 50
      GSIAddConf["HPMAX"] = 50
   end
   ATT7:SetLabel ("(HP Max)")
   ATT7:SetText (tostring(GSIAddConf["HPMAX"]))
   ATT7:SetWidth (60)
   ATT7:DisableButton(true)
   ATT7:SetCallback("OnLeave", function() 
                                   GSIAddConf["HPMAX"] = tonumber(ATT7:GetText()); 
								   end)
   ABText:AddChild (ATT7)
   
   local ATT8 = AceGUI:Create("EditBox")
   if GSIAddConf["MP"] == nil then
      GSIAddConf["MP"] = 50
      GSIAddConf["MPMAX"] = 50
   end
   ATT8:SetLabel ("(PE Max)")
   ATT8:SetText (tostring(GSIAddConf["MPMAX"]))
   ATT8:SetWidth (60)
   ATT8:DisableButton(true)
   ATT8:SetCallback("OnLeave", function() 
                                   GSIAddConf["MPMAX"] = tonumber(ATT7:GetText()); 
								   end)
   ABText:AddChild (ATT8)
   
  
   local LBI1 = AceGUI:Create("Label")
   LBI1:SetText ("-- APTITUDES/HABILIDADES --")
   LBI1:SetWidth (380)
   ABText:AddChild (LBI1)
   local LBI2 = AceGUI:Create("Label")
   LBI2:SetColor(127,127,0)
   LBI2:SetText ("Aptitud                                   Valor   Aptitud                                   Valor")
   LBI2:SetWidth (380)
   ABText:AddChild (LBI2)
   
   local TXI = {}
   local TVI = {}
   if GSIAddConf["TX"] == nil then
      GSIAddConf["TX"] = {}
   end
   if GSIAddConf["TV"] == nil then
      GSIAddConf["TV"] = {}
   end
   for i = 1,GSI_MAX_APP do
      TXI[i] = AceGUI:Create("EditBox")
      if GSIAddConf["TX"][i] == nil then
         GSIAddConf["TX"][i] = ""
      end
      if GSIAddConf["TV"][i] == nil then
         GSIAddConf["TV"][i] = ""
      end
      TXI[i]:SetLabel (nil)
      TXI[i]:DisableButton(true)
      TXI[i]:SetWidth (140)
      TXI[i]:SetText(GSIAddConf["TX"][i])
      TXI[i]:SetCallback("OnLeave", function() 
                                   GSIAddConf["TX"][i] = TXI[i]:GetText(); 
								   end)
      ABText:AddChild (TXI[i])
      TVI[i] = AceGUI:Create("EditBox")
      if GSIAddConf["TV"][i] == nil then
         GSIAddConf["TV"][i] = ""
      end
      TVI[i]:SetLabel (nil)
      TVI[i]:DisableButton(true)
      TVI[i]:SetWidth (40)
      TVI[i]:SetText(GSIAddConf["TV"][i])
      TVI[i]:SetCallback("OnLeave", function() 
                                   GSIAddConf["TV"][i] = TVI[i]:GetText(); 
								   end)
      ABText:AddChild (TVI[i])
   end
end

function GSIAddQueryFicha ( PlayerName )
   SendAddonMessage("GSIADD", "DUMPV:" .. UnitName("Player") ..":2:3:4:5:6:7", "WHISPER", PlayerName )
end
function GSIAdd_Ast ( self, event, msg, ... )
   local arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14 = ...
   msg = string.gsub(msg,"%<.-%>","|cffff8866 %1|r")
   msg = string.gsub(msg,"%*.-%*","|cffff8866 %1|r")
   return false, msg, ...
end

--
-- Popup Dialogs
--
function GSIShowRolGUID ()
   local AceGUI = LibStub("AceGUI-3.0")
   if GSIAddConf["Dmin"] == nil then
      GSIAddConf["Dmin"] = 1
   end
   if GSIAddConf["Dmax"] == nil then
      GSIAddConf["Dmax"] = 100
   end
   if GSIAddConf["RolNotes"] == nil then
      GSIAddConf["RolNotes"] = ""
   end
   local ABText = AceGUI:Create("Frame")
   ABText:SetCallback("OnClose",function(widget) 
	                                 IsRolOpen=false
	                                 AceGUI:Release(widget) 
									 end)
   ABText:SetTitle("Interfaz de rol")
   ABText:SetStatusText("GSIAdd - v"..GSIADD_VERSION.." "..GSIADD_DATE)
   ABText:SetPoint("TOP", -250, -50)
   ABText:SetWidth(350)
   ABText:SetHeight(400)
   ABText:SetLayout("Flow")

   local TX1 = AceGUI:Create("EditBox")
   TX1:SetLabel ( "Emote(barra)")
   TX1:SetCallback ("OnEnterPressed", function() 
	                                          SendChatMessage(TX1:GetText(), "EMOTE" )
										   end)
   TX1:SetText("")
   TX1:SetWidth(300)
   ABText:AddChild (TX1)
   
   local TX2 = AceGUI:Create("EditBox")
   TX2:SetLabel ( "Emote(asteriscos)")
   TX2:SetCallback ("OnEnterPressed", function() 
	                                          SendChatMessage("*" .. TX2:GetText() .. "*", "SAY" )
										   end)
   TX2:SetText("")
   TX2:SetWidth(300)
   ABText:AddChild (TX2)   

   local LB1 = AceGUI:Create("Label")
   LB1:SetText ( "Dados:")
   LB1:SetWidth(50)
   ABText:AddChild (LB1)

   local TXDMIN = AceGUI:Create("EditBox")
   TXDMIN:SetLabel ( "Min.")
   TXDMIN:SetText(tostring(GSIAddConf["Dmin"]))
   TXDMIN:SetCallback("OnLeave", function() GSIAddConf["Dmin"] = tonumber(TXDMIN:GetText()) end)
   TXDMIN:SetWidth(50)
   TXDMIN:DisableButton(true)
   ABText:AddChild (TXDMIN)

   local TXDMAX = AceGUI:Create("EditBox")
   TXDMAX:SetLabel ( "Max.")
   TXDMAX:SetText(tostring(GSIAddConf["Dmax"]))
   TXDMAX:SetCallback("OnLeave", function() GSIAddConf["Dmax"] = tonumber(TXDMAX:GetText()) end)
   TXDMAX:SetWidth(50)
   TXDMAX:DisableButton(true)
   ABText:AddChild (TXDMAX)

   local BTN1 = AceGUI:Create("Button")
   BTN1:SetText ( "Lanzar")
   BTN1:SetWidth(80)
   BTN1:SetCallback("OnClick", function() RandomRoll (tonumber(TXDMIN:GetText()),tonumber(TXDMAX:GetText()))  end)
   ABText:AddChild (BTN1)

   local LB2 = AceGUI:Create("Label")
   local MyText2 = "-- Atributos --\n"
   if GSIAddConf["Fuerza"] ~= nil and GSIAddConf["Fuerza"] > 0 then
     MyText2 = MyText2 .. "Fuerza:" .. GSIAddConf["Fuerza"] .. "\n"
   end
   if GSIAddConf["Intelecto"] ~= nil and GSIAddConf["Intelecto"] > 0 then
     MyText2 = MyText2 .. "Intelecto:" .. GSIAddConf["Intelecto"] .. "\n"
   end
   if GSIAddConf["Agilidad"] ~= nil and GSIAddConf["Agilidad"] > 0 then
     MyText2 = MyText2 .. "Agilidad:" .. GSIAddConf["Agilidad"] .. "\n"
   end
   if GSIAddConf["Espiritu"] ~= nil and GSIAddConf["Espiritu"] > 0 then
     MyText2 = MyText2 .. "Espiritu:" .. GSIAddConf["Espiritu"] .. "\n"
   end
   if GSIAddConf["Carisma"] ~= nil and GSIAddConf["Carisma"] > 0 then
     MyText2 = MyText2 .. "Carisma:" .. GSIAddConf["Carisma"] .. "\n"
   end
   if GSIAddConf["Resistencia"] ~= nil and GSIAddConf["Resistencia"] > 0 then
     MyText2 = MyText2 .. "Resistencia:" .. GSIAddConf["Resistencia"] .. "\n"
   end
   LB2:SetText (MyText2)
   LB2:SetWidth(100)
   ABText:AddChild (LB2)
 
   local LB3 = AceGUI:Create("Label")
   local MyTextH = "-- Habilidades --\n"
   for i = 1, GSI_MAX_APP do
      if GSIAddConf["TX"][i] ~= nil and string.len(GSIAddConf["TX"][i]) > 1 then
         MyTextH = MyTextH .. GSIAddConf["TX"][i] .. ":" .. GSIAddConf["TV"][i] .."\n"
	  end
   end
   LB3:SetText (MyTextH)
   LB3:SetWidth(160)
   ABText:AddChild (LB3)
 
   local NOTAS = AceGUI:Create("MultiLineEditBox")
   NOTAS:SetLabel ( "Notas")
   NOTAS:SetCallback ("OnEnterPressed", function() GSIAddConf["RolNotes"]=NOTAS:GetText() end )
   NOTAS:SetText(GSIAddConf["RolNotes"])
   NOTAS:SetNumLines(2)
   NOTAS:SetWidth(300)
   ABText:AddChild (NOTAS)
   
end

