function GSICombat_LoadVars ()

   if GSIAddConf == nil then
      GSIChar = { 
	     ["GRANGE"] = "off-rol",    -- Rang guild
	     ["LLUM"] = 0,              -- S. Llum
		 ["NATU"] = 0,              -- S. Natural
		 ["ELEM"] = 0,              -- S. Elemental
		 
		 ["VIDA"] = 100,            -- Vida Inicial
		 ["VIBF"] = 0,              -- Buf Vida
end
function FillMenu ()
end
--
-- GLOBAL VARIABLES
--
GSIADD_VERSION      = "1.0"
GSIADD_VERTEXT      = "GSIAdd - WoRP (" .. GSIADD_VERSION .. ")"
