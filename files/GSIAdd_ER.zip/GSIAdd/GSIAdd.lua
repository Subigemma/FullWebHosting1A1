GSIAdd_frame = CreateFrame ("Button", "GSIAdd", UIParent,"UIPanelButtonTemplate" )
GSIAddMenuFrame = CreateFrame("Frame", "GSIAddMenuFrame", UIParent, "UIDropDownMenuTemplate")
GSIAddMenuFrame:SetPoint("TOPLEFT", UIParent, 120, 50)
CloseDropDownMenus()
function PG (text)
   if UnitInParty("player") then
      SendAddonMessage ( "GSIADD", "PRTXT:".. UnitName("player") .. ":A:1:2:3:" .. text .. ":", "PARTY")
   elseif UnitInRaid("player") then						
      SendAddonMessage ( "GSIADD", "PRTXT:".. UnitName("player") .. ":A:1:2:3:" .. text .. ":", "RAID")
   end
   print ( text )
end
function RD (MyMin, MyMax)
   MyRnd = random (MyMin, MyMax)
   PG ( "|cff00ffff[" .. UnitName("Player") .. "]|cffffff00 tira los dados y obtiene " .. MyRnd .. " (" .. MyMin .. "-" .. MyMax .. ")")
   return MyRnd
end
function RT (MyMin, MyMax)
   if UnitName("Target") == nil then
      print ("Debes seleccionar un objetivo primero")
	  return
   end
   MyRnd = random (MyMin, MyMax)
   PG ( "|cffffff00" .. UnitName("Target") .. " tira los dados y obtiene " .. MyRnd .. " (" .. MyMin .. "-" .. MyMax .. ")")
   return MyRnd
end


function GSIAdd_frame:OnEvent(event, ...)
  local arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12 = ...;
  if event == "ADDON_LOADED" and arg1 == "GSIAdd" then
	GSILoadVars()
    GSIAddUpdateBars()
	GSIAdd_SetTimer()
	print ( "|cff00ffff GSIAdd " .. GSIADD_VERSION .. " Listo para el rol!!" ) 
  elseif event == "CHAT_MSG_ADDON" then
	GSIAddProcessMsg( arg2 , arg4)
  elseif event == "UPDATE_MOUSEOVER_UNIT" then
    if UnitIsPlayer(UnitName("mouseover")) then
       SendAddonMessage("GSIADD", "ALRTP:" .. UnitName("Player") .. ":3:4:5:6:7", "WHISPER", UnitName("mouseover"))
	end   
  elseif event == "CHAT_MSG_SAY" then
    if arg6 == "GM" and arg5 == UnitName("Player") and arg1 == ("CHKGMPLY") then
	   print ("CHK-GM")
	   return
	end
     -- print ( "arg1 =[" .. arg1 .."](Texte)")
     -- print ( "arg2 =[" .. arg2 .."](Player-Roiaumme")
     -- print ( "arg3 =[" .. arg3 .."]")
     -- print ( "arg4 =[" .. arg4 .."]")
     -- print ( "arg5 =[" .. arg5 .."]")
     -- print ( "arg6 =[" .. arg6 .."](Player)")
     -- print ( "arg7 =[" .. arg7 .."]")
     -- print ( "arg8 =[" .. arg8 .."]")
     -- print ( "arg9 =[" .. arg9 .."]")
  end
  

end
function GSIAdd_ToggleM ( )
   local GSIAddMenu
--   local MyRealm = GetRealmName()
--   if MyRealm ~= "WorldOfRoleplay" then
--      print ( "WORP: (c) Violation ...")
--	  return
--   end
   local MyGuild = GetGuildInfo("player")
   if MyGuild == nil then
	     MyGuild = ""
   end
   GSIAddMenu = {
         { text = "Social", func = function() GSIAddSocial(); end},
         { text = "Interfaz de rol", func = function() GSIShowRolGUID(); end},
         { text = "Ficha de personaje", func = function() GSIAddFicha(); end},
         { text = "Mostrar/Ocultar barras HP/MP", func = function() 
		                                          if IsBarShow == true then
												     MyHPBar:Hide()
												     MyMPBar:Hide()
													 IsBarShow = false
												  else
												     MyHPBar:Show()
												     MyMPBar:Show()
													 IsBarShow = true
												  end	 
                                               end},
	   }
   if UnitName("Target") ~= nil and UnitIsPlayer ("Target") then
      table.insert ( GSIAddMenu, { text = "Ver ficha de " .. UnitName("Target"), func = function() GSIAddQueryFicha(UnitName("Target")); end} )
 	  table.insert ( GSIAddMenu, { text = "Toque de atencion a " .. UnitName("Target"), 
	  func = function() 
	      StaticPopupDialogs ["GSIADD_ALERT"].text = "Toque de atencion a" .. UnitName("Target")
	      StaticPopup_Show ("GSIADD_ALERT")
	 end} )
	 if MyGuild == "staff" or IsRaidLeader () then
     	  table.insert ( GSIAddMenu, { text = "Inflingir daño a " .. UnitName("Target"), 
    	  func = function() 
    	      StaticPopupDialogs ["GSIADD_PAIN"].text = "Inflingir daño a " .. UnitName("Target")
    	      StaticPopup_Show ("GSIADD_PAIN")
    	 end} )
     	  table.insert ( GSIAddMenu, { text = "Inflingir cansancio a " .. UnitName("Target"), 
    	  func = function() 
    	      StaticPopupDialogs ["GSIADD_TIRED"].text = "Inflingir cansancio a " .. UnitName("Target")
    	      StaticPopup_Show ("GSIADD_TIRED")
    	 end} )
	 end	 
   end
   if UnitName("Target") ~= nil and UnitIsPlayer ("Target") == nil then
      table.insert ( GSIAddMenu, { text = UnitName("Target") .. " Tira dados ..", func = function() 
	                                          StaticPopupDialogs ["GSIADD_DADOS"].text =  UnitName("Target") .. " tira dados "
    	                                      StaticPopup_Show ("GSIADD_DADOS")
											  end} )
   end
   
   if MyGuild == "staff" then
      if UnitName("Target") ~= nil and UnitIsPlayer ("Target") then
         table.insert ( GSIAddMenu, { text = "Modificar MAX atributos a " .. UnitName("Target") , 
	     func = function() 
	         StaticPopupDialogs ["GSIADD_ATTR"].text = "Modificar atributos a" .. UnitName("Target")
	         StaticPopup_Show ("GSIADD_ATTR")
	     end} )
      end
   end   
   
   EasyMenu(GSIAddMenu, GSIAddMenuFrame, GSIAddMenuFrame, 0 , -30, "MENU")
end   

GSIAdd_frame:SetPoint("TOPLEFT", 80, 0)
GSIAdd_frame:SetWidth(80)
GSIAdd_frame:SetHeight(20)
GSIAdd_frame:SetText("GSIAdd")
GSIAdd_frame:RegisterEvent("ADDON_LOADED")    -- Fired when saved variables are loaded
GSIAdd_frame:RegisterEvent("PLAYER_LOGOUT")   -- Fired when about to log out
GSIAdd_frame:RegisterEvent("CHAT_MSG_ADDON")  -- When a MSG_ADDOD
GSIAdd_frame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_GUILD", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_YELL", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY_LEADER", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_LEADER", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_OFFICER", GSIAdd_Ast)
ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", GSIAdd_Ast)
GSIAdd_frame:SetScript("OnEvent", GSIAdd_frame.OnEvent)
GSIAdd_frame:SetScript("OnClick", GSIAdd_ToggleM )

-- MyRc = RegisterAddonMessagePrefix("GSIADD")




