GSI_MAX_ATTR = 30
GSI_MAX_APP = 16
GSIADD_VERSION = "2.1.0"
GSIADD_DATE = "11-2016"
GSIADD_SECS_TIMER = 300
GSIADD_TIMER = 0
GSIADD_TIMER_X2 = 2
GSIADD_TIMER_X4 = 4
GSIADD_TIMER_X8 = 8
IsRolOpen=false
StaticPopupDialogs ["GSIADD_ALERT"] = 
{
	text = "Toque de atencion",
	button1 = "OK" ,
	button2 = "Cancelar" ,
	hideOnEscape = true,
	OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("TOP")
	end,
	OnAccept = function (self, data, data2)
		local TxtEmote = self.editBox:GetText()
        SendAddonMessage("GSIADD", 
	    "SHALRT:" .. UnitName("player") ..":" 
	           .. UnitName("target") .. ":"
			   .. "3:4:5:"
               .. TxtEmote, "WHISPER", UnitName("target") )	
	end,	
	hasEditBox = true,	
	timeout			= 0,
	whileDead		= 1,
	hideOnEscape	= 1,
}
StaticPopupDialogs ["GSIADD_ATTR"] = 
{
	text = "Atributos",
	button1 = "OK" ,
	button2 = "Cancelar" ,
	hideOnEscape = true,
	OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("TOP")
	end,
	OnAccept = function (self, data, data2)
		local MyTxt = self.editBox:GetText()
        SendAddonMessage("GSIADD", 
	    "MODMAT:" .. UnitName("player") ..":" 
	           .. UnitName("target") .. ":"
			   .. MyTxt ..":3:4:5:6"
               , "WHISPER", UnitName("target") )	
	end,	
	hasEditBox = true,	
	timeout			= 0,
	whileDead		= 1,
	hideOnEscape	= 1,
}
StaticPopupDialogs ["GSIADD_PAIN"] = 
{
	text = "Daño",
	button1 = "OK" ,
	button2 = "Cancelar" ,
	hideOnEscape = true,
	OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("TOP")
	end,
	OnAccept = function (self, data, data2)
		local MyTxt = self.editBox:GetText()
        GSIAddSendHP( tonumber(MyTxt), UnitName("target"))
	end,	
	hasEditBox = true,	
	timeout			= 0,
	whileDead		= 1,
	hideOnEscape	= 1,
}
StaticPopupDialogs ["GSIADD_TIRED"] = 
{
	text = "Cansancio",
	button1 = "OK" ,
	button2 = "Cancelar" ,
	hideOnEscape = true,
	OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("TOP")
	end,
	OnAccept = function (self, data, data2)
		local MyTxt = self.editBox:GetText()
        GSIAddSendMP( tonumber(MyTxt), UnitName("target"))
	end,	
	hasEditBox = true,	
	timeout			= 0,
	whileDead		= 1,
	hideOnEscape	= 1,
}
StaticPopupDialogs ["GSIADD_DADOS"] = 
{
	text = "Dados - Valor",
	button1 = "OK" ,
	button2 = "Cancelar" ,
	hideOnEscape = true,
	OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("TOP")
	end,
	OnAccept = function (self, data, data2)
		local MyMax = self.editBox:GetText()
        RT( 1, tonumber(MyMax))
	end,	
	hasEditBox = true,
	timeout			= 0,
	whileDead		= 1,
	hideOnEscape	= 1,
}
function GSILoadVars ()
   if GSIAddConf == nil then
      GSIAddConf = {
	     ["Titulo"] = "",
	     ["Nombre"] = UnitName("Player"),
		 ["Apellidos"] = "",
		 ["Clase"] = UnitClass("Player"),
		 ["Raza"] = UnitRace("Player"),
		 ["Edad"] = "",
		 ["Altura"] = "",
		 ["Rollo"] = "",
		 ["Fuerza"] = 0,
		 ["Intelecto"] = 0,
		 ["Agilidad"] = 0,
		 ["Carisma"] = 0,
		 ["Espiritu"] = 0,
		 ["Resistencia"] = 0,
		 ["PuntosAttr"] = GSI_MAX_ATTR,
		 ["AttrInv"] = 0,
		 }
   end
   if GSIAddConf ["HPMAX"] == nil then
      GSIAddConf ["HPMAX"] = 50
   end
   if GSIAddConf ["MPMAX"] == nil then
      GSIAddConf ["MPMAX"] = 50
   end
   if GSIAddConf ["HP"] == nil then
      GSIAddConf ["HP"] = GSIAddConf ["HPMAX"]
   end
   if GSIAddConf ["MP"] == nil then
      GSIAddConf ["MP"] = GSIAddConf ["MPMAX"]
   end
   if KChars == nil then
      KChars = { ["New"] = "isnew" }
   end	  
   if GSIAddConf ["GSI_MAX_ATTR"] == nil then
      GSI_MAX_ATTR = 30
   else
      GSI_MAX_ATTR = GSIAddConf ["GSI_MAX_ATTR"]
   end
end
function GSIAdd_TimerActions()
   if GSIAddConf["MP"] < GSIAddConf["MPMAX"] then
      GSIAddConf["MP"] = GSIAddConf["MP"] + 1
	  GSIAddUpdateBars()
   end
   GSIADD_TIMER = GSIADD_TIMER + 1
   
   local Mul4 = GSIADD_TIMER % 4
   if Mul4 == 0 then
     if GSIAddConf["HP"] < GSIAddConf["HPMAX"] then
        GSIAddConf["HP"] = GSIAddConf["HP"] + 1
  	  GSIAddUpdateBars()
     end
   end
   
   C_Timer.After(GSIADD_SECS_TIMER, GSIAdd_TimerActions)
end
function GSIAdd_SetTimer ()
   C_Timer.After(GSIADD_SECS_TIMER, GSIAdd_TimerActions)
end
