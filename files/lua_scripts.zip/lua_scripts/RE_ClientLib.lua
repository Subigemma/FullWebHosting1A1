local AIO = AIO or require("AIO")
assert(not RE_ClientLib, "RE_ClientLib is already loaded. Possibly different versions!")
-- RE_ClientLib main table
RE_ClientLib =
{
    -- RE_ClientLib flavour functions
    unpack = unpack,
}

local RE_ClientLib = RE_ClientLib

if not AIO.AddAddon() then
   --
   -- Algunos marcos de trabajo
   --
   StaticPopupDialogs ["RE_NPCDICE"] = 
   {
	   text = "Dados NPC - Valor",
	   button1 = "OK" ,
	   button2 = "Cancelar" ,
	   hideOnEscape = true,
	   OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("CENTER")
	   end,
	   OnAccept = function (self, data, data2)
		   local MyMax = self.editBox:GetText()
           RT( 1, tonumber(MyMax))
	   end,	
	   hasEditBox = true,
	   timeout			= 0,
	   whileDead		= 1,
	   hideOnEscape	= 1,
   }
   StaticPopupDialogs ["RE_DANO"] = 
   {
	   text = "Daño - Introducir valor (negativo para sanidad)",
	   button1 = "OK" ,
	   button2 = "Cancelar" ,
	   hideOnEscape = true,
	   OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("CENTER")
	   end,
	   OnAccept = function (self, data, data2)
		   local MyVal = tonumber(self.editBox:GetText())
		   local MyLife = TRP2RE["RE_Vida"] - MyVal
           TRP2RE["RE_Vida"] = MyLife
           TRP2RE_UpdateBars()
		   RESendMsg("CATTR#" .. UnitName("player") .. ".RE_Vida." .. tostring(MyLife) )
		   if MyVal < 0 then
		      print ("|cff00ffff [RE]:|c00ffff00 Recibido " .. tostring(MyVal*-1) .. " de sanación")
	       else
		      print ("|cff00ffff [RE]:|c00ffff00 Recibido " .. tostring(MyVal) .. " de daño")
		   end
	   end,	
	   hasEditBox = true,
	   timeout			= 0,
	   whileDead		= 1,
	   hideOnEscape	= 1,
   }
   StaticPopupDialogs ["RE_CANSANCIO"] = 
   {
	   text = "Cansancio - Introducir valor (negativo para descanso)",
	   button1 = "OK" ,
	   button2 = "Cancelar" ,
	   hideOnEscape = true,
	   OnShow = function (self, data)
		self.editBox:SetWidth(100)
		self:SetWidth(350)
		self:SetPoint("CENTER")
	   end,
	   OnAccept = function (self, data, data2)
		   local MyVal = tonumber(self.editBox:GetText())
		   local MyMana = TRP2RE["RE_Mana"] - MyVal
		   TRP2RE["RE_Mana"] = MyMana
           TRP2RE_UpdateBars()
		   RESendMsg("CATTR#" .. UnitName("player") .. ".RE_Mana." .. tostring(MyMana) )
		   if MyVal < 0 then
		      print ("|cff00ffff [RE]:|c00ffff00 Recibido " .. tostring(MyVal*-1) .. " de descanso")
	       else
		      print ("|cff00ffff [RE]:|c00ffff00 Recibido " .. tostring(MyVal) .. " de cansancio")
		   end
	   end,	
	   hasEditBox = true,
	   timeout			= 0,
	   whileDead		= 1,
	   hideOnEscape	= 1,
   }
   --
   -- Funciones varias de utilidad
   --
   function PG (text)
      RESendMsg ( "PRTXT"  .. "#" .. UnitName("player") .. "#" .. text )
   end
   function LT ( Player, Attr, Value)
      RESendMsg ( "CATTR" .. "#" .. tostring(Player) .. "." .. tostring(Attr) .. "." .. tostring(Value))
   end
   function RD (MyMin, MyMax)
      MyRnd = random (MyMin, MyMax)
      PG ( "|cff00ffff[" .. UnitName("Player") .. "]|cffffff00 tira los dados y obtiene " .. MyRnd .. " (" ..MyMin .. "-" .. MyMax .. ")")
      return MyRnd
   end
   function RT (MyMin, MyMax)
      if UnitName("Target") == nil then
         print ("Debes seleccionar un objetivo primero")
         return
      end
      MyRnd = random (MyMin, MyMax)
      PG ( "|cffffff00" .. UnitName("Target") .. " tira los dados y obtiene " .. MyRnd .. " (" .. MyMin .. "-" .. MyMax .. ")")
      return MyRnd
   end
   
   --
   -- Funcion para gestionar turnos
   --
   function RE_RolIFC ()
      local AceGUI = LibStub("AceGUI-3.0")
      local ABText = AceGUI:Create("Frame")

      ABText:SetCallback("OnClose",function(widget) 
                          AceGUI:Release(widget) end)
      ABText:SetTitle("Rol Errante - Interfaz de rol - " .. AllFlds[2])
      ABText:SetPoint("TOP", -250, -50)
      ABText:SetWidth(320)
      ABText:SetHeight(450)
      ABText:SetLayout("Flow")
	  
      local TX1 = AceGUI:Create("EditBox")
      TX1:SetWidth(380)
      TX1:SetText  ("")
	  TX1:SetLabel ("Acción (emote)")
	  TX1:DisableButton(true)
      ABText:AddChild (TX1)  
	  
	  local CK1 = AceGUI:Create("CheckBox")
	  CK1:SetLabel ("Emote por banda")
	  CK1:SetType ("checkbox")
	  CK1:SetValue ()
   end	  
else
   PrintInfo("RE Libraries loaded")   
end